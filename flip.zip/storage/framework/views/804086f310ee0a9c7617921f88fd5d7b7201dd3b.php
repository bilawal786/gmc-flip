<?php $__env->startPush('pg_btn'); ?>
    <a href="<?php echo e(route('flips.create')); ?>" class="btn btn-sm btn-neutral">Créer un nouveau FlipBook</a>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-5">
                <div class="card-header bg-transparent">
                    <div class="row">
                        <div class="col-lg-8">
                            <h3 class="mb-0">Tous les Flipbook</h3>
                        </div>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <div>
                            <table class="table table-hover align-items-center">
                                <thead class="thead-light">
                                <tr>
                                    <th scope="col">Nom</th>
                                    <th scope="col">Url</th>
                                    <th scope="col" class="text-center">Action</th>
                                </tr>
                                </thead>
                                <tbody class="list">
                                <?php $__currentLoopData = $flips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row">
                                            <div class="mx-w-440 d-flex flex-wrap">
                                                <?php echo e($flip->name); ?>

                                            </div>
                                        </th>
                                        <td>
                                          <a href="<?php echo e(route('flip.show',$flip->slug)); ?>" target=”_blank”><?php echo e(route('flip.show',$flip->slug)); ?></a>
                                        </td>
                                        <td class="text-center">
                                          <a class="btn btn-primary btn-sm m-1" data-toggle="tooltip" data-placement="top" title="View and edit post details" target=”_blank” href="<?php echo e(route('flip.show', $flip->slug)); ?>">
                                              <i class="fa fa-eye" aria-hidden="true"></i>
                                          </a>
                                            <?php echo Form::open(['route' => ['flips.destroy', $flip],'method' => 'delete',  'class'=>'d-inline-block dform']); ?>

                                            <button type="submit" class="btn delete btn-danger btn-sm m-1" data-toggle="tooltip" data-placement="top" title="Delete post" href="">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /shared/httpd/flip/resources/views/flip/index.blade.php ENDPATH**/ ?>