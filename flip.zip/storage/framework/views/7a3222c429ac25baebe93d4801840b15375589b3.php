<?php echo e($slot); ?>

<?php /**PATH E:\codecanyon\StarterKitPro\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>