<?php $__env->startPush('pg_btn'); ?>
    <a href="<?php echo e(route('post.index')); ?>" class="btn btn-sm btn-neutral">All Posts</a>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-5">
                <div class="card-body">
                    <?php echo Form::open(['route' => ['post.update', $post], 'method'=>'put', 'files' => true]); ?>

                    <h6 class="heading-small text-muted mb-4">Post information</h6>
                        <div class="pl-lg-4">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <?php echo e(Form::label('post_title', 'Post title', ['class' => 'form-control-label'])); ?>

                                        <?php echo e(Form::text('post_title', $post->post_title, ['class' => 'form-control'])); ?>

                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <?php echo e(Form::label('category_id', 'Select Category', ['class' => 'form-control-label'])); ?>

                                        <?php echo e(Form::select('category_id', $categories, $post->category_id, [ 'class'=> 'selectpicker form-control', 'placeholder' => 'Select category...'])); ?>

                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <?php echo e(Form::label('featured_image', 'Featured image', ['class' => 'form-control-label d-block'])); ?>

                                        <div class="input-group">
                                            <span class="input-group-btn">
                                              <a id="uploadFile" data-input="thumbnail" data-preview="holder" class="btn btn-secondary">
                                                <i class="fa fa-picture-o"></i> Choose Image
                                              </a>
                                            </span>
                                            <input id="thumbnail" class="form-control d-none" type="text" name="featured_image">
                                        </div>
                                </div>
                            </div>

                                        <div class="col-md-2">
                                            <?php if($post->featured_image): ?>
                                                <a href="<?php echo e(asset($post->featured_image)); ?>" target="_blank">
                                                    <img alt="Image placeholder"
                                                    class="avatar avatar-xl  rounded-circle"
                                                    data-toggle="tooltip" data-original-title="<?php echo e($post->name); ?> Logo"
                                                    src="<?php echo e(asset($post->featured_image)); ?>">
                                                </a>
                                            <?php endif; ?>
                                    </div>

                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <?php echo e(Form::label('post_body', 'Post Body', ['class' => 'form-control-label'])); ?>

                                        <?php echo Form::textarea('post_body', $post->post_body, ['id'=>"summernote", 'class'=> 'form-control',]); ?>

                                    </div>
                                </div>

                            </div>
                        </div>

                        <hr class="my-4" />
                        <div class="pl-lg-4">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" name="status" value="1" <?php echo e($post->status ? 'checked' : ''); ?>  class="custom-control-input" id="status">
                                        <?php echo e(Form::label('status', 'Status', ['class' => 'custom-control-label'])); ?>

                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <?php echo e(Form::submit('Submit', ['class'=> 'mt-5 btn btn-primary'])); ?>

                                </div>
                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/summernote-bs4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('assets/js/summernote-bs4.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/laravel-filemanager/js/stand-alone-button.js')); ?>"></script>
<script>
    jQuery(document).ready(function() {
        jQuery('#summernote').summernote({
            height: 150,
            toolbar: [
                // [groupName, [list of button]]
                ['style', ['bold', 'italic', 'underline', 'clear']],
                ['font', ['strikethrough', 'superscript', 'subscript']],
                ['fontsize', ['fontsize']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['height', ['height']]
              ]

        });
        jQuery('#uploadFile').filemanager('file');
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\codecanyon\StarterKitPro\resources\views/post/edit.blade.php ENDPATH**/ ?>