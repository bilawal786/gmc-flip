<DOCTYPE html>
    <html lang=”en-US”>
    <head>
    <meta charset="utf-8">
    </head>
    <body>
    <h2>Test Email</h2>
   <p><?php echo e($message); ?></p>
   </body>
   </html>
<?php /**PATH E:\codecanyon\StarterKitPro\resources\views/emails/welcome.blade.php ENDPATH**/ ?>