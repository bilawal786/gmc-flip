<?php $__env->startPush('pg_btn'); ?>
    <a href="<?php echo e(route('flips.index')); ?>" class="btn btn-sm btn-neutral">Tous les Flipbooks</a>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-5">
                <div class="card-body">
                  <?php echo Form::open(['route' => ['flips.update', $flip, 'files' => true], 'method'=>'put']); ?>

                    <h6 class="heading-small text-muted mb-4">Infos du FlipBook</h6>
                        <div class="pl-lg-4">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <?php echo e(Form::label('name', 'Nom', ['class' => 'form-control-label'])); ?>

                                        <?php echo e(Form::text('name', $flip->name, ['class' => 'form-control'])); ?>

                                    </div>
                                </div>

                                <div class="col-md-12">
                                  <div class="form-group">
                                        <?php echo e(Form::label('pdf', 'Fichier PDF', ['class' => 'form-control-label d-block'])); ?>

                                        <div class="custom-file">
                                          <input type="file" name="pdf" class="custom-file-input" id="chooseFile">
                                          <label class="custom-file-label" for="chooseFile">Choisir un PDF</label>
                                        </div>
                                </div>
                              </div>
                            </div>
                        </div>
                        <hr class="my-4" />
                        <?php echo e(Form::submit('Enregistrer', ['class'=> 'btn btn-primary btn-block'])); ?>

                    <?php echo Form::close(); ?>

                </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /shared/httpd/flip/resources/views/flip/edit.blade.php ENDPATH**/ ?>